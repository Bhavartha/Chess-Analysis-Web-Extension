## Chess Analysis

Analyze games played on chess.com using Lichess. 

![gif](https://user-images.githubusercontent.com/33615252/98937080-eb734480-250b-11eb-8257-3b05c58a648a.gif)
